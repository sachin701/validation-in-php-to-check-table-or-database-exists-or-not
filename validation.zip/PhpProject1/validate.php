<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$dbn=$_REQUEST['db'];
$tbn=$_REQUEST['tb'];


$mysql =new mysqli("localhost", "root", "");

if(mysqli_select_db($mysql, $dbn)){
                                    
                                            echo "database exists<br>";
    
                                                          if(mysqli_query($mysql, "DESCRIBE `$tbn`")) {
                                                                        echo "table exist<br>";
                                                                        }
                                                           else{
                                                                
                                                                echo "table doesnt exist<br>";       
                                                                }
       
                                     }

else{
    echo "Databse does not exists and table also doesnt exist <br>";
}
